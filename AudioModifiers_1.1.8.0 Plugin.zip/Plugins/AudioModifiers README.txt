AudioModifiers 1.1.7.0 README
By Xypher Orion

Audio Modifiers changes Beat Saber game audio to use custom sounds
Place your custom files in Beat Saber/CustomAudio

Saber Clash Sounds
Beat Saber/CustomAudio/Clash

Fireworks Explosion Sounds
Beat Saber/CustomAudio/Fireworks

Saber Hit Sounds
Beat Saber/CustomAudio/Hits

Saber Miss Sounds
Beat Saber/CustomAudio/Misses

Menu Music
Beat Saber/CustomAudio/Music

Saber Drone/Whoosh
Beat Saber/CustomAudio/Saber